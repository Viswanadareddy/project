library values;

import 'package:flutter/material.dart';

part 'strings.dart';
part 'colors.dart';
part 'images.dart';
part 'sizes.dart';
