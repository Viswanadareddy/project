class Category {
  String name;
  Category({required this.name});
}
