class News {
  String title;
  String image;

  News({
    required this.title,
    required this.image,
  });
}
