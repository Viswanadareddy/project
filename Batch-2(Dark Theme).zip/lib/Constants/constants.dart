import 'package:flutter/rendering.dart';

class Constants {
  static const kscaffoldcolor = Color(0XFF1b1b1b);
  static const kprimarycolor = Color(0XFF4268e3);
  static const ksecondarycolor = Color(0XFF3e62fe);
  static const kcardcolor = Color(0XFF383e4a);
}
